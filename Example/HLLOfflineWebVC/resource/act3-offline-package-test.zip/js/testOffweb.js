function btnAction()
{
  var xhr = new XMLHttpRequest();
xhr.onreadystatechange = function(){undefined
   if(xhr.readyState===4){undefined
     if(xhr.status===200){ //响应完成且成功
       diplayResult(xhr.responseText);
     }else{  //响应完成但不成功
      diplayResult('响应完成但失败！'+xhr.status);
       
     }
   }
 }
 xhr.open('GET','http://localhost:5555/offweb?bisName=act3-offline-package-test&os=iOS&offlineZipVer=0',true);
xhr.send( null );
}

function diplayResult(txt)
{
 alert(txt);
}
